# Settings for SITL
{
    "pixhawk_ip": "127.0.0.1",
    "pixhawk_udp_port": 14580,
    "local_ethernet_interface_ip": "127.0.0.1",
    "local_udp_port": 14540,
    "serial_port_addr":"/dev/ttyS0",
    "serial_baud_rate":921600
}

# Settings for PX4 running on pixhawk hardware
{
    "pixhawk_ip": "192.168.144.4",
    "pixhawk_udp_port": 14540,
    "local_ethernet_interface_ip": "192.168.144.5",
    "local_udp_port": 14555,
    "serial_port_addr":"/dev/ttyS0",
    "serial_baud_rate":921600
}
